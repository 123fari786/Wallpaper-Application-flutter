package com.example.wallpaper_app_ii

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
