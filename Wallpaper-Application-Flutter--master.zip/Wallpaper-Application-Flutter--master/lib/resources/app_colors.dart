class AppColors {}
